import string  
# This gives us access to pre-made strings of characters. 

import sys
# access to python cli sys.argv

import hashlib
# librarby that lets us use hash

# reading files from our computer
import sys
import os

# #################### Stage 3 #################################

# Cipher, algorithms, modes: This is the core AES math engine.
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

# PBKDF2HMAC and hashes: The slow-loop password protection engine.
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

# padding: A tool to make sure our files fit perfectly into AES's rigid 16-byte blocks.
from cryptography.hazmat.primitives import padding

###########################################################################################

# string.ascii_lowercase is a built-in shortcut for "abcdefghijklmnopqrstuvwxyz".
alphabet = string.ascii_lowercase

# A unique marker to isolate our hash signature from the cipher text
HASH_MARKER = "---HASH_BOUNDARY---\n"

def caesar_encrypt(text, shift):
    # an empty string to hold our scrambled text.
    result = "" 

    # Loops through every character in your text. char.isalpha() checks if it's a letter. If it's a space or a punctuation mark, it skips straight down to the else: statement.
    for char in text:
        if char.isalpha():
            # we have to keep track if it was uppercase 
            is_upper = char.isupper() # boolean value

            current_index = alphabet.index(char.lower())

            new_index = (current_index + shift) % 26   # to avoid if cindex becomes 27 or so

            new_char = alphabet[new_index]

            # Put it back to uppercase if it started that way
            if is_upper:
                result += new_char.upper()
            else:
                result += new_char
        else:
            result += char

    return result

def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)

# hash function
def compute_hash(text):
    # encode() converts the string to bytes, which hashlib needs
    # .hexdigest() returns it as a clean readable text string.
    
    return hashlib.sha256(text.encode()).hexdigest()

# frequency analysis
# Creating a dictionary to count how many times each letter shows up in the scrambled text.
def frequency_analysis(ciphertext):
    counts = {}

    for char in ciphertext.lower():
        if char.isalpha():
            # If char is already a key, it returns its value 
            # If char is not yet in the dictionary, it returns 0 
            counts[char] = counts.get(char, 0) + 1

    # if the file has zero readable letters
    if not counts:
        print("Error: No alphabetical characters found to analyze.")
        return
    
    # Sorting found letters from most frequent to least frequent
    sorted_letters = sorted(counts, key=counts.get, reverse=True)

    print("\n--- Frequency Analysis: Top 5 Likely predictions ---\n")

    # Increased range to 5 so we have a better chance
    for i in range(min(5, len(sorted_letters))):

        # Dynamically pulling the characters down the frequency list
        most_common = sorted_letters[i]

        index_of_most_common = alphabet.index(most_common)

        # 'e' is the most common letter in the English language
        index_of_e = alphabet.index('e')

        # The % 26 ensures that if the distance ends up negative, it wraps cleanly into a valid positive shift number.
        guessed_shift = (index_of_most_common - index_of_e) % 26

        # Bringing back the decryption assignment block using our guessed shift key
        decrypted = caesar_decrypt(ciphertext, guessed_shift)

        print(f"Guess {i+1} (Assuming '{most_common}' is 'e' -> Shift {guessed_shift}):")
        print(f"  {decrypted[:80]}\n")


############################ Stage 2 ################################

# hash guard is like a wax seal — before locking the box, you take a "fingerprint" of the letter. 
# When you unlock it, you check if the fingerprint still matches. If someone tampered with it, the fingerprint won't match.

# What is a hash?
# A hash is a function that takes any text and produces a fixed-length "fingerprint" string.
# That fingerprint is called a hash.

# Python has a built-in library called hashlib that does this for us.

# b means "bytes". Hashlib needs bytes, not a plain string. .encode() converts it.

# SHA‑256 is a cryptographic hash function from the SHA‑2 family that generates a fixed 256‑bit output, usually represented as a 64‑character hexadecimal string. 
# It is deterministic, meaning the same input always produces the same output, but it is irreversible, so the original data cannot be reconstructed from the hash.

# #################################### Stage 3 #######################################################

# 1] KEY DERIVATION

# Next, we need a function that takes your typed text password (like "mycoolpassword") 
# and stretches it out 100,000 times to create a strong, 32-byte key.

# It takes your string password and a random salt (which is just a handful of random data bytes
# to ensure no two passwords hash to the same value).

# It hashes it recursively 100,000 times using SHA-256.
# This is the exact step that completely shuts down high-speed hacker guessing tools!

def derive_key(password: str, salt: bytes) -> bytes:
    """Stretches a password 100,000 times using a random salt to make a strong key."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 32 bytes = 256 bits
        salt=salt,
        iterations=100000,
    )
    return kdf.derive(password.encode())



# 2] The Encryption Engine
# This function will take your raw file bytes, pad them out so they fit into the 16-byte AES blocks, encrypt them,
# and glue the salt and IV to the front of the file.

def encrypt(data: bytes, password: str) -> bytes:
    """Encrypts binary data using AES-256-CBC with a random Salt and IV."""

    # Generate fresh random 16-byte salt and 16-byte IV
    salt = os.urandom(16)  #asks our operating system for absolutely random noise to create the Salt and IV.
    iv = os.urandom(16)
    
    # Generate the 32-byte key from our password
    key = derive_key(password, salt)
    
    # AES needs data to perfectly fit into 16-byte blocks (PKCS7 Padding)
    # padding.PKCS7(128) calculates how many dummy bytes your file needs to cleanly divide by 16 and glues them onto the end.
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    
    # Initialize the AES-256-CBC cipher engine
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    
    # PACKING THE HEADER: Gluing salt + IV directly to the front of the ciphertext
    return salt + iv + ciphertext


# 3]The Decryption Engine

# Next, we need the matching puzzle piece: the code that unpeels that header, recalculates the key, decrypts the blocks, and strips away the dummy padding bytes.

def decrypt(encrypted_data: bytes, password: str) -> bytes:
    """Extracts metadata from the header and decrypts AES-256-CBC ciphertext."""
    if len(encrypted_data) < 32:
        print("Error: Encrypted file is corrupted or too short.")
        sys.exit(1)
        
    # Slicing the first 32 bytes to extract Salt and IV
    salt = encrypted_data[:16]
    iv = encrypted_data[16:32]
    ciphertext = encrypted_data[32:]
    
    # Derive the exact same key using the extracted salt
    key = derive_key(password, salt)
    
    # Initialize the decryption engine
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    
    try:
        padded_data = decryptor.update(ciphertext) + decryptor.finalize()
        
        # Strip away the PKCS7 padding bytes safely
        unpadder = padding.PKCS7(128).unpadder()
        return unpadder.update(padded_data) + unpadder.finalize()
    except ValueError:
        # If the password is wrong, the padding won't align mathematically
        print("Error: Decryption failed. Incorrect password or corrupted data.")
        sys.exit(1)


# ##################### CLI COMMANDS ###############################


if len(sys.argv) < 3:
    print('''
  WELCOME TO CRYPTOVAULT UTILITY

[CAESAR SYNTAX]
  • encrypt : python cryptovault.py encrypt <file> --shift <n>
  • decrypt : python cryptovault.py decrypt <file> --shift <n> [--verify]
  • crack   : python cryptovault.py crack <file>

[AES SYNTAX]
  • encrypt : python cryptovault.py encrypt <file> --password <pass>
  • decrypt : python cryptovault.py decrypt <file> --password <pass>
''')
    sys.exit(1)

command = sys.argv[1]
filepath = sys.argv[2] 

# Automatically Routing to Stage 3 AES Code block if '--password' is used
if "--password" in sys.argv:
    # Read the file as raw binary bytes
    try:
        with open(filepath, 'rb') as f:
            content = f.read()
    except FileNotFoundError:
        print(f"Error: The file '{filepath}' could not be found.")
        sys.exit(1)

    # based on command
    if command == "encrypt":
        if len(sys.argv) < 5 or sys.argv[3] != "--password":
            print("Error: Syntax must be: --password <pass>")
            sys.exit(1)
            
        password_input = sys.argv[4]
        output_data = encrypt(content, password_input)
        out_file = filepath + ".enc"
        
        with open(out_file, 'wb') as f:
            f.write(output_data)
        print(f"[OK] AES encrypted file written to → {out_file}")

    elif command == "decrypt":
        if len(sys.argv) < 5 or sys.argv[3] != "--password":
            print("Error: Syntax must be: --password <pass>")
            sys.exit(1)
            
        password_input = sys.argv[4]
        output_data = decrypt(content, password_input)
        
        # removing .enc tag to restore original name
        out_file = filepath.replace(".enc", "")
        if out_file == filepath:
            out_file = filepath + ".dec"
            
        with open(out_file, 'wb') as f:
            f.write(output_data)
        print(f"[OK] Decrypted file restored to → {out_file}")
    else:
        print(f"Unknown command: '{command}'")

# Route to Stage 1 & 2 Caesar Code block if '--shift' or 'crack' is used
else:
    # Opening our target text file and reading all its words into a variable called content with a safety wrapper
    try:
        with open(filepath, 'r') as f:
            content = f.read() 
    except FileNotFoundError:
        print(f"Error: The file '{filepath}' could not be found.")
        sys.exit(1)

    # Route execution based on command
    if command == "encrypt":

        # protect from input parsing
        if len(sys.argv) < 5 or sys.argv[3] != "--shift":
            print("Error: Encryption requires a shift amount ")
            sys.exit(1)
            
        shift = int(sys.argv[4])

        # stage 2 - 
        original_hash = compute_hash(content) #returns a 64-character SHA-256 alphanumeric string
        encrypted = caesar_encrypt(content, shift)
        final_payload = original_hash + "\n" + HASH_MARKER + encrypted

        out_file = filepath + ".enc"
        
        # Added the file engine to save the encrypted text to your machine
        with open(out_file, 'w') as f:
            f.write(final_payload)
        print(f"Encrypted content written to → {out_file}")

    elif command == "decrypt":
        # protection input parsing
        if len(sys.argv) < 5 or sys.argv[3] != "--shift":
            print("Error: Decryption requires a shift amount ")
            sys.exit(1)
            
        shift = int(sys.argv[4])

        # stage 2-
        #Check if the user passed the optional "--verify" flag anywhere in the CLI command
        verify = "--verify" in sys.argv 

        # Unpack the file payload. We need to split the string using our unique marker.
        if HASH_MARKER in content:
            # split(..., 1) splits only at the first occurrence of the marker
            parts = content.split(HASH_MARKER, 1)
            stored_hash = parts[0].strip() # Strip removes the trailing newline \n
            edited_content = parts[1]
        else:
            # Fallback mechanism in case we test it against old Stage 1 files that have no embedded hash
            print("[!] Notice: No integrity hash structure detected in file. Decrypting raw file content instead.")
            stored_hash = None
            edited_content = content  

        decrypted = caesar_decrypt(edited_content, shift)

        # verification process
        if verify:
            if stored_hash is None:
                print("Verification Error: Cannot verify integrity. This file does not contain an embedded hash seal.")
            else:
                # Re-calculate the fingerprint of what we just decrypted
                calculated_hash = compute_hash(decrypted)
                
                # main thingy - comparing original wax seal vs current wax seal
                if calculated_hash == stored_hash:
                    print("INTEGRITY VERIFIED: The file hash matches perfectly. No data corruption detected.")
                else:
                    print("[!!!!!!] WARNING: TAMPER DETECTED! The decrypted file hash does not match the original signature.")
                    print(f"    Stored Hash:     {stored_hash}")
                    print(f"    Calculated Hash: {calculated_hash}")

        out_file = filepath.replace(".enc", "") + ".dec"

        # Adding the file engine to save the code to our machine
        with open(out_file, 'w') as f:
            f.write(decrypted)
        print(f"Decrypted content written to → {out_file}")

    # Tied the crack keyword directly into our frequency analysis tool
    elif command == "crack":

        # If we are trying to crack a Stage 2 file, we have to bypass the hash wrapper so frequency logic isn't confused by hex characters
        if HASH_MARKER in content:
            content = content.split(HASH_MARKER, 1)[1]
        frequency_analysis(content)

    else:
        print(f"Unknown command: '{command}'. Please use encrypt, decrypt, or crack.")