# CYBERSECURITY BASIC TASK WRITE-UP

## By Hiba Fathima - 106125040 - CSE B

When I approached this assignment, my goal wasn't just to write code that worked, but to understand **why** behind whatever i wrote. I am a beginner to cybersecurity but it is one domain i have always wanted to explore.

I used ai for this task, but as my tutor. Since i am new to tis domain i didnt know where to start or how to approach in the beginning ... so i took help from ai to assist me along the way. But i made sure and i am satisfied that i understood each and every line of code i wrote.

Thanks to this task, now i know atleast something abt cybersecurity. And i am excited that i found an interest in this domain. So i worked on Cybersecurity domain task too. I am curious abt this domain and i really wanna learn more.

Thank you for the Task!!!

## Stage 1: Caesar Cipher Lock

### 1. Concept

I started by learning what Ceasar Cipher is.. it is way that people years back used to encode a secret message. The core concept here is modulo arithmetic applied to language: taking a text letter, converting it to its alphabet index (0 to 25), and adding a fixed secret key shifting constant.

So i first built a basic script that takes a normal text letter, finds its position in the alphabet (0 to 25), and shifts it forward by a secret number key. If the shift goes past "Z", it wraps back around to the beginning using modulo 26 math.

### 2. Advantage of this method

It’s great for hiding a message from a casual glance or hiding quick text answers inside a code file.

### 3. Limitations & Vulnerabilities

There are only 25 possible keys to shift by. A computer can try all of them and break it in less than a millisecond.
Also, it keeps all word spaces and letter patterns perfectly visible and in the same place, so anyone can easily guess the words.
The math behind frequency analysis completely depends on having large text samples to allow statistical averages to balance out naturally.So we need large text blocks to generate a accurate result.

### 4. My Implementation Journey: Errors & Results

- When trying to decrypt , my code kept hitting negative numbers which kept causing a crash.
  I realized I needed to explicitly wrap the index using the modulo operator % 26. This automatically cycles negative numbers back around to the end of the alphabet grid

- when decrypting the text mentioned in the task -"Wkh txlfn eurzq ira mxpsv ryhu wkh odcb grj. Fubswrjudskb lv wkh duw ri zulwlqj dqg vroylqj frghv" to get the top 3 results i never got a proper sentence.
  my script output completely unreadable garbage! I looked at my logic and found that because the text block was so short, the letters 'w', 'h', and 'r' all appeared exactly 5 times
  So to increase the chances i ran the frequency analysis 5 times to find top 5 common letters to get 5 results. I instantly found the correct plaintext cracked at a shift key of 3.

### 5. Terms and Concepts I Learned

- **Monoalphabetic Substitution:** A method of encryption where each letter in the plaintext is mapped to a single fixed letter down the alphabet line.

- **Keyspace:** The total number of possible keys that could be used to decrypt a cipher. For the Caesar cipher, the keyspace is incredibly small—just 25 possible shifts.

- **Frequency Analysis:** A technique that uses the fact that certain letters in a human language appear much more often than others (like "E", "T", and "A" in English).

# Questions from the task

## Why is Caesar trivially breakable?

The Caesar cipher is kinda easy to crack!! because it has only 25 possible shifts in the English alphabet. A modern computer can run through every single one of these combinations using a brute-force attack easily..

Additionally, the cipher fails to hide the underlying structure of the message. It leaves word spaces, sentence lengths, punctuation marks, and repeating letter patterns exactly where they were originally.

Changing one letter in out message changes exactly one letter in the secret code. Because it changes things so predictably, it fails to confuse anyone trying to crack it.

## What property of language makes frequency analysis work?

Frequency analysis works because human language is not statistically random and instead possesses a strict, predictable habit. In written English, we naturally use letters like 'E', 'T', and 'A' way more often than rare letters like 'Z' or 'Q'. This creates a highly distinct wave of peaks across the alphabet.

To crack it, we just find the tallest peak in our secret code and count the steps back to the most common alphatbet in english 'E'.

---

## Stage 2: Hash Guard

In this stage I realized that encrypting a file only locks it from being read, not from being messed with. I had to do something to verify that the data wasn't modified or broken

### 1. Concepts I Learned

Stage 2 focused on basic **Data Integrity**. So we had to add a --verify flag that uses the SHA-256 algorithm to generate a unique 32-byte digital fingerprint (a hash) of the file before it gets encrypted.
This hash is appended directly into the encrypted output file. On decryption, the script recalculates the file's hash and compares it to the stored one to ensure they match perfectly.

This is like a password to verify if the data is changed or not.

### 2. Terms I learnt

- **Cryptographic Hashing (SHA-256):** function that takes any amount of input data and turns it into a fixed-size, 32-byte digital fingerprint..this is called a hash . It is a one-way..wecan never reverse a hash back into the original file.

- **SHA-256** - Secure Hash Algorithm 256-bit is a cryptographic hash function that takes an input of any size and processes it into a fixed-size, 64-character hexadecimal string

- **Data Integrity:** Ensuring that data has not been altered, deleted, or corrupted in transit or storage.

- **Bit Flipping / Tampering:** An attack where someone alters the bits of a ciphertext file to change or break the final decrypted message, even if they don't know the decryption password.

### 3. Advantages

The biggest advantage is that it introduces a reliable way to verify if a file has been altered. By comparing the calculated SHA-256 hash before encryption and after decryption, the script can definitively tell you if even a single bit of data was changed while it was stored or transmitted.

Files can degrade over time due to storage drive errors. The hash guard flags identifies structural failures immediately, acting as a quality check before weopen a file.

In basic ciphers, an attacker can modify parts of the encrypted file without knowing the key. While they can't read it, they can systematically break it. This Hash guard catches this tampering immediately and halts execution.

### 3. Limitations & Vulnerabilities

If someone completely intercepts our file system, they can swap out our original file with a malicious one, calculate a fresh SHA-256 hash for their bad file, encrypt it, and package it back up.

The hash guard is purely a detection mechanism. If it discovers that a file has been corrupted or tampered with, it can only warn you and abort execution. It cannot reconstruct or repair the damaged parts of the file; out data is effectively lost if the validation fails.

### 4. My Implementation Journey: Errors & Results

When i first tried to feed the data into Python’s hashlib.sha256() function to generate our digital fingerprint, the script threw a strict TypeError: object doing buffer interface cannot be string

Then i realized that SHA-256 algorithm cannot process standard, formatted Python text strings directly; it strictly requires raw, unformatted binary data blocks (bytes). Because we were reading our file data as regular text, the hashing function rejected it.

I altered how my script interacted with the files.I ensured the data text strings were explicitly transformed into raw byte formats using Python's .encode() method right before passing them into the hash generator.

# Questions from the task

## Encryption gives confidentiality. Hashing gives integrity. Why do you need both?

Encryption is like locking our message inside an iron safe...it stops outsiders from peeking inside (confidentiality), but it can't stop someone from dropping the safe or hitting it with a sledgehammer.

If an attacker scrambles the scrambled binary data blocks while it's locked, our computer will blindly decrypt it anyway, spitting out corrupted junk or broken text.

Hashing acts like a unique, wax seal on that safe (integrity). By combining both, our program checks the seal first: if an attacker altered even a single bit of the file, the hash shatters instantly, the system sounds an alarm, and it refuses to process the damaged file.

we need both because encryption keeps our data a secret, but hashing proves that our secret hasn't been broken or tampered with.

## Stage 3: AES upgrade

In this stage, I realized that real-world security operates on raw bits and bytes, not just English text characters. So we need to upgrade to use a military-grade symmetric block cipher.

### 1. Concepts I Learned

In this stage i focused on implementing the **Advanced Encryption Standard (AES)**

Instead of reading files as text strings, the script now uses binary mode (`'rb'` and `'wb'`) to handle data as raw byte streams. This means the tool can now safeguard anything—text files, images, PDFs, or compiled programs—without destroying their underlying data structure.

Because human-entered passwords are short and predictable, I learned that they make terrible cryptographic keys. To fix this, I implemented **PBKDF2 Key Derivation** to mathematically stretch human passwords into high-entropy, uniform 256-bit keys.

I also learned that AES processes data in rigid 16-byte blocks. If a file isn't a perfect multiple of 16 bytes, the algorithm fails. I implemented **PKCS7 Padding** to symmetrically add dummy bytes to round up the file size before encryption, which are then stripped away cleanly during decryption.

## 2. Terms I Learnt

- **Symmetric Encryption:** A cryptographic system where the exact same secret key is used for both encrypting the data and decrypting it.

- **PBKDF2 (Password-Based Key Derivation Function 2):** A key-stretching algorithm that takes a weak user password, combines it with a random salt, and runs it through a hashing primitive (like SHA-256) inside an intensive computational loop (**100,000 iterations**). This intentional slowdown makes high-speed GPU brute-force attacks useless.

- **Salt:** A sequence of 16 random bytes mixed with the password before hashing. This ensures that if two users use the exact same password, their derived cryptographic keys will be completely different, preventing precomputed dictionary attacks.

- **Initialization Vector (IV):** A random 16-byte data block mixed with the first block of plaintext before it gets encrypted.

- **Semantic Security (Pattern Hiding):** A security property ensuring that an adversary cannot glean any structural patterns from the ciphertext. Thanks to unique IVs, encrypting the exact same file multiple times will yield entirely different ciphertext outputs every single run.
- **Packed Binary File Header:** A custom layout format where metadata (the unique 16-byte Salt and 16-byte IV) is glued directly to the front of the raw encrypted ciphertext payload so the decryption engine can extract them later.

### 3. Advantages

AES-256 uses a key state space of 2 power 256. This number is so structurally massive that all the supercomputers on Earth running for billions of years could not brute-force it.

Because of CBC mode and unique IVs, there is no language structural leakage. Word gaps, repeating letters, and file headers are completely randomized.

Operating on raw binary streams means the script can encrypt an image or a database file just as easily as a standard text file.

### 4. Limitations & Vulnerabilities

Because Cipher Block Chaining (CBC) requires each data block to be mixed mathematically with the ciphertext block right before it, the encryption process cannot be split up across multiple CPU cores (no parallel processing).

While our PKCS7 padding layer will throw a formatting error if a file is tampered with, CBC mode lacks an active, cryptographic Message Authentication Code (MAC) to natively guarantee the identity of the person who encrypted it.

---

### 5. My Implementation Journey: Errors & Results

When testing what happens when a user types an incorrect password, my script crashed out with a cryptic `ValueError: Invalid padding bytes` trackback error.

I realized that an incorrect password leads to a bad derived key, which makes the decryption engine produce randomized garbage bytes instead of the true padding scheme. I wrapped the unpadding process inside a`try-except` block to capture the `ValueError` preventing an system crash and outputting a polite user error message instead.

My script now successfully locks down files with AES-256-CBC! When I run the command, it creates a fully encrypted `topsecret.txt.enc` file that looks like unreadable binary. When tested with a bad password, it handles the failure gracefully without dumping corrupted data onto my hard drive.

# Questions from the task

## What Goes Wrong if the IV is Reused?

Let us think of the IV (Initialization Vector) as a random starting line. If we reuse the same IV and password for two different files, we lose our pattern-hiding security.

If both files start with the same text their encrypted versions will look 100% identical up until the point where the words change. if we send the exact same message twice, the output will look exactly the same.

hacker watching our files won't know our password, but they will instantly spot the patterns, match duplicate messages, and can even use math to peel back the encryption blocks completely.

Using a fresh, random IV every single time ensures the exact same message turns into completely different digital noise every run.

## What does PBKDF2 add that a plain hash doesn’t?

Let us think of a plain hash like a basic house key. If a hacker steals our key layout, their specialized machine can copy it and try matching it against billions of locks

PBKDF2 stops this by doing two things:

The Salt (Adding a Custom Lock): It glues random extra data to your password. This means even if two people have the exact same password, they get completely different keys

The Slowdown Loop (Adding 100,000 Turns): Instead of checking the key once, it forces the lock to spin in a loop 100,000 times before opening. It takes a normal person just a split-second to unlock, but it completely ruins a hacker's high-speed guessing machine.

## This project showed me how deep this field really is, and I’m incredibly eager to bring this exact problem-solving mindset into the club, learn from seniors, and start contributing! Thank you.
